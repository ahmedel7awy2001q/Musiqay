package com.musiqay.app.playback

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.*
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.*
import com.musiqay.app.MainActivity
import com.musiqay.app.R
import com.musiqay.app.util.isRadioMediaId
import com.musiqay.app.util.radioRetryDelayMs

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class PlaybackService : MediaSessionService() {
    companion object {
        private var activePlayer: ExoPlayer? = null
        val audioSessionId: Int get() = activePlayer?.audioSessionId ?: C.AUDIO_SESSION_ID_UNSET
    }
    private var mediaSession: MediaSession? = null
    private var player: ExoPlayer? = null
    private val recoveryHandler = Handler(Looper.getMainLooper())
    private var retryAttempt = 0
    private val radioListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            recoveryHandler.removeCallbacksAndMessages(null); retryAttempt = 0
        }
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) { retryAttempt = 0; recoveryHandler.removeCallbacksAndMessages(null) }
        }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            val current = player ?: return
            if (!playWhenReady) {
                recoveryHandler.removeCallbacksAndMessages(null); retryAttempt = 0
                if (isRadioMediaId(current.currentMediaItem?.mediaId)) current.stop()
            } else if (isRadioMediaId(current.currentMediaItem?.mediaId) && current.playbackState == Player.STATE_IDLE) {
                current.seekToDefaultPosition(); current.prepare()
            }
        }
        override fun onPlayerError(error: PlaybackException) {
            val current = player ?: return
            val key = current.currentMediaItem?.mediaId
            if (!isRadioMediaId(key) || !current.playWhenReady) return
            recoveryHandler.removeCallbacksAndMessages(null)
            val delayMs = radioRetryDelayMs(retryAttempt++)
            if (delayMs == null) { current.pause(); return }
            recoveryHandler.postDelayed({
                if (current.currentMediaItem?.mediaId == key && current.playWhenReady) {
                    current.seekToDefaultPosition(); current.prepare()
                }
            }, delayMs)
        }
    }
    override fun onCreate() {
        super.onCreate()
        setMediaNotificationProvider(DefaultMediaNotificationProvider.Builder(this).build().apply {
            setSmallIcon(R.drawable.ic_stat_musiqay)
        })
        val http = DefaultHttpDataSource.Factory().setUserAgent("Musiqay/1.4 (Android)")
            .setConnectTimeoutMs(10_000).setReadTimeoutMs(12_000).setAllowCrossProtocolRedirects(true)
        val exoPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            .setHandleAudioBecomingNoisy(true).build()
        val activity = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        // The official Quran HLS includes static video; select its audio track only.
        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
        activePlayer = exoPlayer; player = exoPlayer
        exoPlayer.addListener(radioListener)
        mediaSession = MediaSession.Builder(this, exoPlayer).setSessionActivity(activity).build()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession
    override fun onDestroy() {
        recoveryHandler.removeCallbacksAndMessages(null)
        mediaSession?.release(); mediaSession = null; activePlayer = null
        player?.release(); player = null
        super.onDestroy()
    }
}
