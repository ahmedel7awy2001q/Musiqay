package com.musiqay.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

enum class ThemeMode { SYSTEM, DARK, LIGHT }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val dynamicColors: Boolean = false,
    val minimumAudioDurationSeconds: Int = 10,
    val includeNonMusicAudio: Boolean = false,
    val hiddenFolders: Set<String> = emptySet(),
    val reduceMotion: Boolean = false
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val RADIO_FAVORITES = stringSetPreferencesKey("radio_favorites")
        val LAST_RADIO = stringPreferencesKey("last_radio_station")
        val THEME = stringPreferencesKey("theme")
        val DYNAMIC = booleanPreferencesKey("dynamic_colors")
        val MIN_AUDIO_DURATION = intPreferencesKey("minimum_audio_duration_seconds")
        val INCLUDE_NON_MUSIC = booleanPreferencesKey("include_non_music_audio")
        val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
        val HIDDEN_FOLDERS = stringSetPreferencesKey("hidden_folders")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            themeMode = runCatching {
                ThemeMode.valueOf(
                    prefs[Keys.THEME] ?: ThemeMode.DARK.name
                )
            }.getOrDefault(ThemeMode.DARK),

            dynamicColors = prefs[Keys.DYNAMIC] ?: false,

            minimumAudioDurationSeconds =
                prefs[Keys.MIN_AUDIO_DURATION] ?: 10,

            includeNonMusicAudio =
                prefs[Keys.INCLUDE_NON_MUSIC] ?: false,

            hiddenFolders = prefs[Keys.HIDDEN_FOLDERS] ?: emptySet(),
            reduceMotion = prefs[Keys.REDUCE_MOTION] ?: false
        )
    }

    val radioFavorites: Flow<Set<String>> = context.dataStore.data.map { it[Keys.RADIO_FAVORITES] ?: emptySet() }
    val lastRadioStation: Flow<String?> = context.dataStore.data.map { it[Keys.LAST_RADIO] }
    suspend fun toggleRadioFavorite(id: String) {
        if (id.isBlank() || id.length > 80) return
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.RADIO_FAVORITES] ?: emptySet()
            prefs[Keys.RADIO_FAVORITES] = if (id in current) current - id else current + id
        }
    }
    suspend fun saveLastRadio(id: String) {
        if (id.isBlank() || id.length > 80) return
        context.dataStore.edit { it[Keys.LAST_RADIO] = id }
    }
    suspend fun setReduceMotion(enabled: Boolean) {
        context.dataStore.edit { it[Keys.REDUCE_MOTION] = enabled }
    }

    suspend fun setTheme(mode: ThemeMode) {
        context.dataStore.edit {
            it[Keys.THEME] = mode.name
        }
    }

    suspend fun setDynamicColors(enabled: Boolean) {
        context.dataStore.edit {
            it[Keys.DYNAMIC] = enabled
        }
    }

    suspend fun setMinimumAudioDuration(seconds: Int) {
        val safeValue = seconds.coerceIn(0, 3600)

        context.dataStore.edit {
            it[Keys.MIN_AUDIO_DURATION] = safeValue
        }
    }

    suspend fun setIncludeNonMusicAudio(enabled: Boolean) {
        context.dataStore.edit {
            it[Keys.INCLUDE_NON_MUSIC] = enabled
        }
    }

    suspend fun hideFolder(folder: String) {
        val clean = folder.trim()
        if (clean.isBlank()) return
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.HIDDEN_FOLDERS] ?: emptySet()
            prefs[Keys.HIDDEN_FOLDERS] = current + clean
        }
    }

    suspend fun showFolder(folder: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.HIDDEN_FOLDERS] ?: emptySet()
            prefs[Keys.HIDDEN_FOLDERS] = current - folder
        }
    }

    suspend fun clearHiddenFolders() {
        context.dataStore.edit { prefs -> prefs.remove(Keys.HIDDEN_FOLDERS) }
    }
}
